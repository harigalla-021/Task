package com.cg.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import com.cg.dto.Application;
import com.cg.dto.ProgramScheduled;
import com.cg.util.DBUtil;
import com.cg.util.MyStringDateUtil;

public class MACDAOImpl implements MACDAO {

	Connection con;
	PreparedStatement pstmt = null;

	public MACDAOImpl() {
	
	}

	public List<ProgramScheduled> getAllScheduledPrograms() {
		List<ProgramScheduled> programScheduledList = new ArrayList<>();

		String qry = "SELECT * FROM Programs_Scheduled";

		try {
			con= DBUtil.getConnection();
			pstmt = con.prepareStatement(qry);
			ResultSet resultSet = pstmt.executeQuery();
			while (resultSet.next()) {
				ProgramScheduled programScheduled = new ProgramScheduled();
				
				programScheduled.setScheduledProgramId(resultSet
						.getString(1));
				programScheduled.setProgramName(resultSet
						.getString(2));
				programScheduled.setLocation(resultSet.getString(3));
				programScheduled.setStartDate(resultSet.getDate(4));
				programScheduled.setEndDate(resultSet.getDate(5));
				programScheduled.setSessionsPerWeek(resultSet
						.getInt(6));
				programScheduledList.add(programScheduled);
			}
		} catch (SQLException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return programScheduledList;
	}

	@Override
	public String updateStatus(String status, int id) {
		String qry = "Update Application set status=? where Application_id=?";
		int result = 0;
		try {
			con= DBUtil.getConnection();
			pstmt = con.prepareStatement(qry);
			pstmt.setString(1, status);
			pstmt.setInt(2, id);
			result = pstmt.executeUpdate();
		} catch (SQLException | IOException e) {
			e.printStackTrace();
		}
		if (result > 0) {
			return status;
		} else {
			// add throw new next time
			return null;
		}

	}

	@Override
	public int setInterviewDate(LocalDate date, int id) {
		int result = 0;
		java.sql.Date sqlDate = java.sql.Date.valueOf(date);
		String qry = "Update Application set Date_Of_Interview=? where Application_id=?";
		try {
			con= DBUtil.getConnection();
			pstmt = con.prepareStatement(qry);
			pstmt.setDate(1, sqlDate);
			pstmt.setInt(2, id);
			result = pstmt.executeUpdate();
		} catch (SQLException | IOException e) {
			e.printStackTrace();
		}
		return result;
	}

	@Override
	public List<Application> showApplicationByStatus(String status) {

		List<Application> applicantList = new ArrayList<Application>();

		String qry = "SELECT * FROM Application where status=?";
		try {
			con= DBUtil.getConnection();
			pstmt = con.prepareStatement(qry);
			pstmt.setString(1,status);
			ResultSet resultSet = pstmt.executeQuery();
			while (resultSet.next())
			{
				if((resultSet.getDate(10))==null)
				{
				applicantList.add(new Application(resultSet.getInt(1),resultSet.getString(2),MyStringDateUtil.fromSqlToLocalDate(resultSet.getDate(3)),resultSet.getString(4),
						resultSet.getInt(5),resultSet.getString(6),resultSet.getString(7),resultSet.getString(8),resultSet.getString(9)));
			    }
				else
				{
					applicantList.add(new Application(resultSet.getInt(1),resultSet.getString(2),MyStringDateUtil.fromSqlToLocalDate(resultSet.getDate(3)),resultSet.getString(4),
							resultSet.getInt(5),resultSet.getString(6),resultSet.getString(7),resultSet.getString(8),resultSet.getString(9),MyStringDateUtil.fromSqlToLocalDate(resultSet.getDate(10))));
				}
				
			
		} }
		catch (SQLException | IOException e) {
			
			e.printStackTrace();
		}
		
		return applicantList;
	}

	@Override
	public List<Application> getAllApplications() {
		// TODO Auto-generated method stub
		List<Application> list= new ArrayList<Application>();
		String qry= "SELECT* FROM APPLICATION";
		try {
			con= DBUtil.getConnection();
			pstmt = con.prepareStatement(qry);
			ResultSet resultSet = pstmt.executeQuery();
			while (resultSet.next())
			{
				if((resultSet.getDate(10))==null)
				{
				list.add(new Application(resultSet.getInt(1),resultSet.getString(2),MyStringDateUtil.fromSqlToLocalDate(resultSet.getDate(3)),resultSet.getString(4),
						resultSet.getInt(5),resultSet.getString(6),resultSet.getString(7),resultSet.getString(8),resultSet.getString(9)));
			    }
				else
				{
					list.add(new Application(resultSet.getInt(1),resultSet.getString(2),MyStringDateUtil.fromSqlToLocalDate(resultSet.getDate(3)),resultSet.getString(4),
							resultSet.getInt(5),resultSet.getString(6),resultSet.getString(7),resultSet.getString(8),resultSet.getString(9),MyStringDateUtil.fromSqlToLocalDate(resultSet.getDate(10))));
				}
			}
			
		} 
		catch (SQLException | IOException e) {
			
			e.printStackTrace();
		}
		return list;
	}

	@Override
	public String ReturnStatus(int id) {
		// TODO Auto-generated method stub
		String status=null;
		String qry= "SELECT STATUS FROM APPLICATION WHERE APPLICATION_ID=?";
		try {
			con= DBUtil.getConnection();
			pstmt = con.prepareStatement(qry);
			pstmt.setInt(1, id);
			ResultSet resultSet = pstmt.executeQuery();
			resultSet.next();
			status=resultSet.getString(1);
		} 
		catch (SQLException | IOException e) {
			
			e.printStackTrace();
		}
		return status;
	}

}
